package com.cs.umbc.project.client;

import com.google.gwt.core.client.EntryPoint;
import com.google.gwt.event.logical.shared.SelectionEvent;
import com.google.gwt.event.logical.shared.SelectionHandler;
import com.google.gwt.user.client.ui.HTML;
import com.google.gwt.user.client.ui.HorizontalPanel;
import com.google.gwt.user.client.ui.RootPanel;
import com.google.gwt.user.client.ui.TabPanel;
import com.google.gwt.user.client.ui.VerticalPanel;

/**
 * 
 * @author Ran
 * 
 */
public class HomePanel implements EntryPoint {

	public void onModuleLoad() {

		Login login=new Login();
		RootPanel.get().add(login);
		
		
	}

}
